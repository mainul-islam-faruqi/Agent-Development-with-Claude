# Run summary — 20260920_222750

- Model: `claude-haiku-4-5-20251001`
- Fixtures processed: 8
- Estimated total cost: **$0.1713** USD

| claim_id | outcome | claim_type | severity | turns | clarifications_asked | input_tokens | output_tokens | est_cost_usd | elapsed_s |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| claim_01_kitchen_fire | routed | property_damage | medium | 4 | 0 | 16535 | 557 | 0.0193 | 15.3 |
| claim_02_stolen_bike | routed | theft | low | 4 | 0 | 15306 | 416 | 0.0174 | 11.1 |
| claim_03_water_damage | routed | property_damage | high | 6 | 1 | 22177 | 1177 | 0.0281 | 13.9 |
| claim_04_neighbor_injury | routed | liability | high | 4 | 0 | 14192 | 846 | 0.0184 | 10.7 |
| claim_05_auto_collision | routed | auto | high | 5 | 0 | 18822 | 983 | 0.0237 | 11.2 |
| claim_06_low_confidence_escalation | escalated | property_damage,auto,liability | - | 5 | 2 | 21034 | 1214 | 0.0271 | 19.9 |
| claim_07_tree_falls_on_car | routed | auto | medium | 4 | 1 | 16187 | 598 | 0.0192 | 12.7 |
| claim_08_minor_porch_damage | routed | property_damage | low | 4 | 0 | 14061 | 801 | 0.0181 | 8.4 |
